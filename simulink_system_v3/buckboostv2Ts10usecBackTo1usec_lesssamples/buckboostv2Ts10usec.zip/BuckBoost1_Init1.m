clear
clc
Ts=1e-3;%1e-4;
Imax=16;
Vin=40;
R=30;